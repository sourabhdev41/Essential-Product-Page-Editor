<?php
/**
 * Elementor Widget: Add to Cart + Buy Now + Quantity block.
 *
 * @package Essential_Product_Page_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

/**
 * Class EPE_Cart_Buy_Widget
 */
class EPE_Cart_Buy_Widget extends Widget_Base {

	public function get_name() {
		return 'epe-cart-buy-widget';
	}

	public function get_title() {
		return __( 'Add to Cart / Buy Now', 'essential-product-page-editor' );
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	public function get_categories() {
		return array( 'epe-category' );
	}

	public function get_keywords() {
		return array( 'woocommerce', 'add to cart', 'buy now', 'quantity', 'cart', 'checkout' );
	}

	public function get_script_depends() {
		return array( 'epe-script' );
	}

	public function get_style_depends() {
		return array( 'epe-style' );
	}

	/**
	 * All registered controls.
	 */
	protected function register_controls() {
		$this->register_content_layout_section();
		$this->register_content_quantity_section();
		$this->register_content_add_to_cart_section();
		$this->register_content_buy_now_section();

		$this->register_style_section(
			'quantity',
			__( 'Quantity Box', 'essential-product-page-editor' ),
			'.epe-qty-buttons-row',
			'.epe-qty-input, .epe-qty-btn',
			true
		);
		$this->register_style_section(
			'atc',
			__( 'Add to Cart Button', 'essential-product-page-editor' ),
			'.epe-btn-atc',
			'.epe-btn-atc',
			false
		);
		$this->register_style_section(
			'buynow',
			__( 'Buy Now Button', 'essential-product-page-editor' ),
			'.epe-btn-buynow',
			'.epe-btn-buynow',
			false
		);
	}

	/* =========================================================
	 * CONTENT: Layout
	 * ========================================================= */
	protected function register_content_layout_section() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => __( 'Layout', 'essential-product-page-editor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_responsive_control(
			'layout_direction',
			array(
				'label'     => __( 'Buttons Direction', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'row'    => array(
						'title' => __( 'Row (side by side)', 'essential-product-page-editor' ),
						'icon'  => 'eicon-arrow-right',
					),
					'column' => array(
						'title' => __( 'Column (stacked)', 'essential-product-page-editor' ),
						'icon'  => 'eicon-arrow-down',
					),
				),
				'default'        => 'row',
				'tablet_default' => 'row',
				'mobile_default' => 'column',
				'selectors'      => array(
					'{{WRAPPER}} .epe-buttons-wrap' => 'flex-direction: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buttons_order',
			array(
				'label'   => __( 'Buttons Order', 'essential-product-page-editor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'buynow_first',
				'options' => array(
					'buynow_first' => __( 'Buy Now, then Add to Cart', 'essential-product-page-editor' ),
					'atc_first'    => __( 'Add to Cart, then Buy Now', 'essential-product-page-editor' ),
				),
			)
		);

		$this->add_responsive_control(
			'quantity_position',
			array(
				'label'   => __( 'Quantity Position', 'essential-product-page-editor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'above',
				'options' => array(
					'above'  => __( 'Above buttons', 'essential-product-page-editor' ),
					'inline' => __( 'Inline with Add to Cart', 'essential-product-page-editor' ),
					'hidden' => __( 'Hidden', 'essential-product-page-editor' ),
				),
			)
		);

		$this->add_responsive_control(
			'buttons_gap',
			array(
				'label'      => __( 'Gap Between Elements', 'essential-product-page-editor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 16,
				),
				'tablet_default' => array(
					'unit' => 'px',
					'size' => 14,
				),
				'mobile_default' => array(
					'unit' => 'px',
					'size' => 12,
				),
				'selectors'  => array(
					'{{WRAPPER}} .epe-buttons-wrap' => 'gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .epe-qty-buttons-row' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'content_align',
			array(
				'label'     => __( 'Alignment', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'essential-product-page-editor' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'essential-product-page-editor' ),
						'icon'  => 'eicon-text-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'essential-product-page-editor' ),
						'icon'  => 'eicon-text-align-right',
					),
					'stretch'    => array(
						'title' => __( 'Justify / Full Width', 'essential-product-page-editor' ),
						'icon'  => 'eicon-text-align-justify',
					),
				),
				'default'   => 'stretch',
				'selectors' => array(
					'{{WRAPPER}} .epe-product-block' => 'align-items: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/* =========================================================
	 * CONTENT: Quantity
	 * ========================================================= */
	protected function register_content_quantity_section() {
		$this->start_controls_section(
			'section_qty',
			array(
				'label' => __( 'Quantity Settings', 'essential-product-page-editor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_quantity',
			array(
				'label'        => __( 'Show Quantity Selector', 'essential-product-page-editor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __( 'Show', 'essential-product-page-editor' ),
				'label_off'    => __( 'Hide', 'essential-product-page-editor' ),
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'qty_default',
			array(
				'label'     => __( 'Default Quantity', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1,
				'min'       => 1,
				'condition' => array( 'show_quantity' => 'yes' ),
			)
		);

		$this->add_control(
			'qty_min',
			array(
				'label'     => __( 'Minimum Quantity', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1,
				'min'       => 1,
				'condition' => array( 'show_quantity' => 'yes' ),
			)
		);

		$this->add_control(
			'qty_max',
			array(
				'label'       => __( 'Maximum Quantity', 'essential-product-page-editor' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'description' => __( 'Set 0 to use the product\'s own stock/back-order limit.', 'essential-product-page-editor' ),
				'condition'   => array( 'show_quantity' => 'yes' ),
			)
		);

		$this->add_control(
			'qty_step',
			array(
				'label'     => __( 'Step', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1,
				'min'       => 1,
				'condition' => array( 'show_quantity' => 'yes' ),
			)
		);

		$this->add_control(
			'qty_button_style',
			array(
				'label'     => __( 'Plus / Minus Icon Style', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'text',
				'options'   => array(
					'text' => __( 'Text ( + / - )', 'essential-product-page-editor' ),
					'icon' => __( 'Icon Style', 'essential-product-page-editor' ),
				),
				'condition' => array( 'show_quantity' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/* =========================================================
	 * CONTENT: Add to Cart
	 * ========================================================= */
	protected function register_content_add_to_cart_section() {
		$this->start_controls_section(
			'section_atc',
			array(
				'label' => __( 'Add to Cart Settings', 'essential-product-page-editor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_atc',
			array(
				'label'        => __( 'Show Add to Cart Button', 'essential-product-page-editor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'atc_text',
			array(
				'label'     => __( 'Button Text', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Add to cart', 'essential-product-page-editor' ),
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_loading_text',
			array(
				'label'     => __( 'Loading Text', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Adding...', 'essential-product-page-editor' ),
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_added_text',
			array(
				'label'     => __( 'Added Text', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Added ✓', 'essential-product-page-editor' ),
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_ajax',
			array(
				'label'        => __( 'Add via AJAX (no page reload)', 'essential-product-page-editor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'condition'    => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_redirect_type',
			array(
				'label'     => __( 'After Adding to Cart', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => array(
					'none'     => __( 'Stay on Page', 'essential-product-page-editor' ),
					'cart'     => __( 'Redirect to Cart', 'essential-product-page-editor' ),
					'checkout' => __( 'Redirect to Checkout', 'essential-product-page-editor' ),
					'custom'   => __( 'Redirect to Custom URL', 'essential-product-page-editor' ),
				),
				'condition' => array(
					'show_atc' => 'yes',
					'atc_ajax!' => 'yes',
				),
				'description' => __( 'Redirect options apply when AJAX is turned off (standard form submit).', 'essential-product-page-editor' ),
			)
		);

		$this->add_control(
			'atc_redirect_url',
			array(
				'label'       => __( 'Custom Redirect URL', 'essential-product-page-editor' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://your-site.com/thank-you/',
				'condition'   => array(
					'show_atc'          => 'yes',
					'atc_ajax!'         => 'yes',
					'atc_redirect_type' => 'custom',
				),
			)
		);

		$this->end_controls_section();
	}

	/* =========================================================
	 * CONTENT: Buy Now
	 * ========================================================= */
	protected function register_content_buy_now_section() {
		$this->start_controls_section(
			'section_buynow',
			array(
				'label' => __( 'Buy Now Settings', 'essential-product-page-editor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_buynow',
			array(
				'label'        => __( 'Show Buy Now Button', 'essential-product-page-editor' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'buynow_text',
			array(
				'label'     => __( 'Button Text', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Buy Now', 'essential-product-page-editor' ),
				'condition' => array( 'show_buynow' => 'yes' ),
			)
		);

		$this->add_control(
			'buynow_checkout_type',
			array(
				'label'       => __( 'Checkout Destination', 'essential-product-page-editor' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'native',
				'options'     => array(
					'native' => __( 'Native WooCommerce Checkout', 'essential-product-page-editor' ),
					'custom' => __( 'Custom Link', 'essential-product-page-editor' ),
				),
				'condition'   => array( 'show_buynow' => 'yes' ),
				'description' => __( 'The product is added to the cart first, then the customer is sent to this destination.', 'essential-product-page-editor' ),
			)
		);

		$this->add_control(
			'buynow_custom_url',
			array(
				'label'       => __( 'Custom Checkout URL', 'essential-product-page-editor' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://your-site.com/custom-checkout/',
				'condition'   => array(
					'show_buynow'           => 'yes',
					'buynow_checkout_type' => 'custom',
				),
			)
		);

		$this->end_controls_section();
	}

	/* =========================================================
	 * STYLE (shared builder for Quantity / ATC / Buy Now)
	 * ========================================================= */
	protected function register_style_section( $key, $label, $box_selector, $text_selector, $is_quantity ) {

		// Pill-style defaults matching the reference design, per section.
		$default_bg     = '';
		$default_text   = '';
		$default_radius = array(
			'top'      => 50,
			'right'    => 50,
			'bottom'   => 50,
			'left'     => 50,
			'unit'     => 'px',
			'isLinked' => true,
		);
		$default_height = array(
			'unit' => 'px',
			'size' => 62,
		);
		$default_padding = array(
			'top'      => 0,
			'right'    => 32,
			'bottom'   => 0,
			'left'     => 32,
			'unit'     => 'px',
			'isLinked' => false,
		);

		if ( 'atc' === $key ) {
			$default_bg   = '#3F8F97';
			$default_text = '#FFFFFF';
		} elseif ( 'buynow' === $key ) {
			$default_bg   = '#DD5C5C';
			$default_text = '#FFFFFF';
		} elseif ( 'quantity' === $key ) {
			$default_bg      = 'transparent';
			$default_text    = '#333333';
			$default_padding = array(
				'top'      => 4,
				'right'    => 18,
				'bottom'   => 4,
				'left'     => 18,
				'unit'     => 'px',
				'isLinked' => false,
			);
		}

		$this->start_controls_section(
			'section_style_' . $key,
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		if ( ! $is_quantity ) {
			$this->add_responsive_control(
				$key . '_width',
				array(
					'label'      => __( 'Width', 'essential-product-page-editor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 50,
							'max' => 800,
						),
						'%'  => array(
							'min' => 10,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => '%',
						'size' => 100,
					),
					'selectors'  => array(
						"{{WRAPPER}} {$box_selector}" => 'width: {{SIZE}}{{UNIT}}; max-width: 100%;',
					),
				)
			);

			$this->add_responsive_control(
				$key . '_height',
				array(
					'label'      => __( 'Height', 'essential-product-page-editor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px' ),
					'default'    => $default_height,
					'mobile_default' => array(
						'unit' => 'px',
						'size' => 52,
					),
					'range'      => array(
						'px' => array(
							'min' => 20,
							'max' => 150,
						),
					),
					'selectors'  => array(
						"{{WRAPPER}} {$box_selector}" => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);
		}

		$this->add_control(
			$key . '_heading_typo',
			array(
				'label'     => __( 'Typography', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => $key . '_typography',
				'selector' => "{{WRAPPER}} {$text_selector}",
			)
		);

		$this->start_controls_tabs( $key . '_colors_tabs' );

		$this->start_controls_tab(
			$key . '_tab_normal',
			array( 'label' => __( 'Normal', 'essential-product-page-editor' ) )
		);

		$this->add_control(
			$key . '_text_color',
			array(
				'label'     => __( 'Text Color', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => $default_text,
				'selectors' => array(
					"{{WRAPPER}} {$text_selector}" => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			$key . '_bg_color',
			array(
				'label'     => __( 'Background Color', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => $default_bg,
				'selectors' => array(
					"{{WRAPPER}} {$box_selector}" => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$key . '_tab_hover',
			array( 'label' => __( 'Hover', 'essential-product-page-editor' ) )
		);

		$this->add_control(
			$key . '_text_color_hover',
			array(
				'label'     => __( 'Text Color', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					"{{WRAPPER}} {$box_selector}:hover {$text_selector}, {{WRAPPER}} {$box_selector}:hover" => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			$key . '_bg_color_hover',
			array(
				'label'     => __( 'Background Color', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					"{{WRAPPER}} {$box_selector}:hover" => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			$key . '_border_color_hover',
			array(
				'label'     => __( 'Border Color', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					"{{WRAPPER}} {$box_selector}:hover" => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			$key . '_heading_border',
			array(
				'label'     => __( 'Border & Shape', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => $key . '_border',
				'selector'       => "{{WRAPPER}} {$box_selector}",
				'fields_options' => 'quantity' === $key ? array(
					'border' => array( 'default' => 'solid' ),
					'width'  => array(
						'default' => array(
							'top'      => 1,
							'right'    => 1,
							'bottom'   => 1,
							'left'     => 1,
							'unit'     => 'px',
							'isLinked' => true,
						),
					),
					'color'  => array( 'default' => '#E2E2E2' ),
				) : array(),
			)
		);

		$this->add_responsive_control(
			$key . '_radius',
			array(
				'label'      => __( 'Border Radius', 'essential-product-page-editor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => $default_radius,
				'selectors'  => array(
					"{{WRAPPER}} {$box_selector}" => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => $key . '_shadow',
				'selector' => "{{WRAPPER}} {$box_selector}",
			)
		);

		$this->add_control(
			$key . '_heading_spacing',
			array(
				'label'     => __( 'Spacing', 'essential-product-page-editor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			$key . '_padding',
			array(
				'label'      => __( 'Padding', 'essential-product-page-editor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'default'    => $default_padding,
				'selectors'  => array(
					"{{WRAPPER}} {$box_selector}" => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			$key . '_margin',
			array(
				'label'      => __( 'Margin', 'essential-product-page-editor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					"{{WRAPPER}} {$box_selector}" => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/* =========================================================
	 * RENDER
	 * ========================================================= */
	protected function render() {
		global $product;

		$settings = $this->get_settings_for_display();

		if ( ! $product instanceof WC_Product ) {
			$product = wc_get_product( get_the_ID() );
		}

		if ( ! $product instanceof WC_Product ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="epe-editor-notice">' . esc_html__( 'This widget only works inside a Single Product template (e.g. via Elementor Theme Builder) or on a real Product page.', 'essential-product-page-editor' ) . '</div>';
			}
			return;
		}

		if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			echo '<div class="epe-product-block epe-unavailable">' . esc_html( $product->is_in_stock() ? __( 'This product cannot be purchased.', 'essential-product-page-editor' ) : __( 'Out of stock.', 'essential-product-page-editor' ) ) . '</div>';
			return;
		}

		$product_id = $product->get_id();

		$qty_min     = ! empty( $settings['qty_min'] ) ? absint( $settings['qty_min'] ) : 1;
		$qty_max_raw = isset( $settings['qty_max'] ) ? absint( $settings['qty_max'] ) : 0;
		$qty_step    = ! empty( $settings['qty_step'] ) ? absint( $settings['qty_step'] ) : 1;
		$qty_default = ! empty( $settings['qty_default'] ) ? absint( $settings['qty_default'] ) : $qty_min;

		$stock_limit = $product->get_max_purchase_quantity();
		if ( $qty_max_raw > 0 ) {
			$qty_max = ( $stock_limit > 0 ) ? min( $qty_max_raw, $stock_limit ) : $qty_max_raw;
		} else {
			$qty_max = ( $stock_limit > 0 ) ? $stock_limit : '';
		}

		$show_quantity = 'yes' === $settings['show_quantity'];
		$show_atc      = 'yes' === $settings['show_atc'];
		$show_buynow   = 'yes' === $settings['show_buynow'];

		$atc_ajax_class = ( 'yes' === $settings['atc_ajax'] ) ? 'epe-ajax' : 'epe-no-ajax';

		$atc_redirect_type = isset( $settings['atc_redirect_type'] ) ? $settings['atc_redirect_type'] : 'none';
		$atc_redirect_url  = ! empty( $settings['atc_redirect_url']['url'] ) ? $settings['atc_redirect_url']['url'] : '';

		$buynow_checkout_type = isset( $settings['buynow_checkout_type'] ) ? $settings['buynow_checkout_type'] : 'native';
		$buynow_custom_url    = ! empty( $settings['buynow_custom_url']['url'] ) ? $settings['buynow_custom_url']['url'] : '';

		$qty_position = isset( $settings['quantity_position'] ) ? $settings['quantity_position'] : 'above';
		if ( ! $show_quantity ) {
			$qty_position = 'hidden';
		}

		?>
		<div class="epe-product-block" data-product-id="<?php echo esc_attr( $product_id ); ?>">
			<form class="epe-form epe-form-atc <?php echo esc_attr( $atc_ajax_class ); ?>" method="post" enctype="multipart/form-data" data-redirect-type="<?php echo esc_attr( $atc_redirect_type ); ?>" data-redirect-url="<?php echo esc_url( $atc_redirect_url ); ?>">

				<?php if ( 'above' === $qty_position ) : ?>
					<?php $this->render_quantity_markup( $qty_default, $qty_min, $qty_max, $qty_step, $settings ); ?>
				<?php endif; ?>

				<div class="epe-buttons-wrap">

					<?php if ( 'inline' === $qty_position ) : ?>
						<?php $this->render_quantity_markup( $qty_default, $qty_min, $qty_max, $qty_step, $settings ); ?>
					<?php endif; ?>

					<?php
					$atc_button_html = '';
					if ( $show_atc ) {
						ob_start();
						?>
						<button
							type="submit"
							name="add-to-cart"
							value="<?php echo esc_attr( $product_id ); ?>"
							class="epe-btn epe-btn-atc"
							data-loading-text="<?php echo esc_attr( $settings['atc_loading_text'] ); ?>"
							data-added-text="<?php echo esc_attr( $settings['atc_added_text'] ); ?>"
							data-default-text="<?php echo esc_attr( $settings['atc_text'] ); ?>"
						>
							<span class="epe-btn-label"><?php echo esc_html( $settings['atc_text'] ); ?></span>
						</button>
						<?php
						$atc_button_html = ob_get_clean();
					}

					$buynow_button_html = '';
					if ( $show_buynow ) {
						ob_start();
						?>
						<button
							type="submit"
							formaction="<?php echo esc_url( add_query_arg( array(), '' ) ); ?>"
							name="epe_buy_now"
							value="<?php echo esc_attr( $product_id ); ?>"
							class="epe-btn epe-btn-buynow"
							formmethod="post"
						>
							<span class="epe-btn-label"><?php echo esc_html( $settings['buynow_text'] ); ?></span>
						</button>
						<input type="hidden" name="epe_redirect_type" value="<?php echo esc_attr( $buynow_checkout_type ); ?>" />
						<input type="hidden" name="epe_redirect_url" value="<?php echo esc_url( $buynow_custom_url ); ?>" />
						<input type="hidden" name="epe_nonce" value="<?php echo esc_attr( wp_create_nonce( 'epe_buy_now_action' ) ); ?>" />
						<?php
						$buynow_button_html = ob_get_clean();
					}

					$buttons_order = isset( $settings['buttons_order'] ) ? $settings['buttons_order'] : 'buynow_first';

					if ( 'atc_first' === $buttons_order ) {
						echo $atc_button_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo $buynow_button_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					} else {
						echo $buynow_button_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo $atc_button_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					?>

				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Output the quantity selector markup.
	 */
	protected function render_quantity_markup( $default, $min, $max, $step, $settings ) {
		if ( 'hidden' === ( $settings['quantity_position'] ?? '' ) || 'yes' !== $settings['show_quantity'] ) {
			return;
		}
		?>
		<div class="epe-qty-wrap">
			<div class="epe-qty-buttons-row">
				<button type="button" class="epe-qty-btn epe-qty-minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'essential-product-page-editor' ); ?>">−</button>
				<input
					type="number"
					class="epe-qty-input"
					name="quantity"
					value="<?php echo esc_attr( $default ); ?>"
					min="<?php echo esc_attr( $min ); ?>"
					<?php echo ( '' !== $max ) ? 'max="' . esc_attr( $max ) . '"' : ''; ?>
					step="<?php echo esc_attr( $step ); ?>"
					inputmode="numeric"
				/>
				<button type="button" class="epe-qty-btn epe-qty-plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'essential-product-page-editor' ); ?>">+</button>
			</div>
		</div>
		<?php
	}
}
