/* global jQuery, wc_add_to_cart_params */
( function ( $ ) {
	'use strict';

	function clampQty( $input ) {
		var val  = parseInt( $input.val(), 10 );
		var min  = parseInt( $input.attr( 'min' ), 10 ) || 1;
		var max  = $input.attr( 'max' ) ? parseInt( $input.attr( 'max' ), 10 ) : null;
		var step = parseInt( $input.attr( 'step' ), 10 ) || 1;

		if ( isNaN( val ) ) {
			val = min;
		}
		if ( val < min ) {
			val = min;
		}
		if ( null !== max && val > max ) {
			val = max;
		}
		$input.val( val );
		return val;
	}

	$( document ).on( 'click', '.epe-qty-plus', function ( e ) {
		e.preventDefault();
		var $wrap  = $( this ).closest( '.epe-qty-buttons-row' );
		var $input = $wrap.find( '.epe-qty-input' );
		var step   = parseInt( $input.attr( 'step' ), 10 ) || 1;
		var max    = $input.attr( 'max' ) ? parseInt( $input.attr( 'max' ), 10 ) : null;
		var val    = ( parseInt( $input.val(), 10 ) || 0 ) + step;

		if ( null !== max && val > max ) {
			val = max;
		}
		$input.val( val );
		$input.trigger( 'change' );
	} );

	$( document ).on( 'click', '.epe-qty-minus', function ( e ) {
		e.preventDefault();
		var $wrap  = $( this ).closest( '.epe-qty-buttons-row' );
		var $input = $wrap.find( '.epe-qty-input' );
		var step   = parseInt( $input.attr( 'step' ), 10 ) || 1;
		var min    = parseInt( $input.attr( 'min' ), 10 ) || 1;
		var val    = ( parseInt( $input.val(), 10 ) || 0 ) - step;

		if ( val < min ) {
			val = min;
		}
		$input.val( val );
		$input.trigger( 'change' );
	} );

	$( document ).on( 'change', '.epe-qty-input', function () {
		clampQty( $( this ) );
	} );

	/**
	 * AJAX Add to Cart (when the widget's "Add via AJAX" is enabled).
	 * Falls back to a normal form submit if wc_add_to_cart_params
	 * (the WooCommerce core add-to-cart script data) isn't available.
	 */
	$( document ).on( 'submit', 'form.epe-form-atc.epe-ajax', function ( e ) {
		var $form = $( this );

		// Only intercept the Add to Cart button, not the Buy Now button.
		var $submitter = $( document.activeElement );
		if ( ! $submitter.hasClass( 'epe-btn-atc' ) ) {
			return; // let Buy Now (or others) submit normally.
		}

		if ( 'undefined' === typeof window.wc_add_to_cart_params ) {
			return; // no AJAX endpoint info available - normal submit.
		}

		e.preventDefault();

		var $button     = $submitter;
		var productId   = $button.val();
		var $qtyInput   = $form.find( '.epe-qty-input' );
		var quantity    = $qtyInput.length ? clampQty( $qtyInput ) : 1;
		var defaultText = $button.data( 'default-text' );
		var loadingText = $button.data( 'loading-text' ) || '...';
		var addedText   = $button.data( 'added-text' ) || 'Added';

		$button.prop( 'disabled', true );
		$button.find( '.epe-btn-label' ).text( loadingText );

		$.ajax( {
			type: 'POST',
			url: window.wc_add_to_cart_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'add_to_cart' ),
			data: {
				product_id: productId,
				quantity: quantity,
			},
			success: function ( response ) {
				if ( ! response ) {
					return;
				}
				if ( response.error && response.product_url ) {
					window.location = response.product_url;
					return;
				}

				$( document.body ).trigger( 'added_to_cart', [ response.fragments, response.cart_hash, $button ] );

				$button.find( '.epe-btn-label' ).text( addedText );

				var redirectType = $form.data( 'redirect-type' );
				var redirectUrl  = $form.data( 'redirect-url' );

				if ( 'cart' === redirectType ) {
					window.location = window.wc_add_to_cart_params.cart_url;
					return;
				}
				if ( 'checkout' === redirectType ) {
					window.location = window.wc_add_to_cart_params.checkout_url || '/checkout/';
					return;
				}
				if ( 'custom' === redirectType && redirectUrl ) {
					window.location = redirectUrl;
					return;
				}

				setTimeout( function () {
					$button.prop( 'disabled', false );
					$button.find( '.epe-btn-label' ).text( defaultText );
				}, 1500 );
			},
			error: function () {
				$button.prop( 'disabled', false );
				$button.find( '.epe-btn-label' ).text( defaultText );
			},
		} );
	} );
} )( jQuery );
