=== Essential Product Page Editor ===
Contributors: nrwindia
Tags: elementor, woocommerce, add to cart, buy now, quantity
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Elementor addon by NRW India to fully design a WooCommerce Quantity + Add to Cart
+ Buy Now block: colors, fonts, borders, radius, width, spacing, and choice of
Native Checkout or Custom URL redirect for Buy Now.

== Description ==

Essential Product Page Editor adds a single Elementor widget, "Add to Cart / Buy Now",
that you can drop into any Single Product Elementor template (works great with
Elementor Theme Builder / Pro, or directly on a WooCommerce product page built with
Elementor).

Features:

* Quantity selector with +/- stepper (min, max, step, default all configurable)
* Add to Cart button with optional AJAX (no page reload) and post-add redirect
  (stay on page / cart / checkout / custom URL)
* Buy Now button: adds to cart then redirects to the Native WooCommerce Checkout
  OR any Custom URL you specify
* Full style control for each element (Quantity box, Add to Cart button, Buy Now
  button) independently:
  - Typography (font family, size, weight, spacing, line height)
  - Text & background color (Normal and Hover states)
  - Border (width, style, color) + independent corner radius
  - Box shadow
  - Padding, margin, width, height, gap
* Automatic updates from GitHub (see Plugin URI)

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/ or install the zip via
   Plugins > Add New > Upload Plugin.
2. Activate the plugin. Elementor and WooCommerce must already be active.
3. Edit a Single Product template (or a product page) with Elementor and drag
   in the "Add to Cart / Buy Now" widget, found under the
   "Essential Product Page Editor" category.

== Updates ==

This plugin checks https://github.com/sourabhdev41/essential-product-page-editor
for new releases. Tag a new release in that repository (bumping the "Version:"
header in the main plugin file) to publish an update to sites running this plugin.

== Changelog ==

= 1.0.0 =
* Initial release.
