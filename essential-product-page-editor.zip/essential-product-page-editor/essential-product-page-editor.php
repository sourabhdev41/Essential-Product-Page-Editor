<?php
/**
 * Plugin Name:       Essential Product Page Editor
 * Plugin URI:        https://github.com/sourabhdev41/essential-product-page-editor
 * Description:       Elementor addon to design a fully custom WooCommerce Quantity + Add to Cart + Buy Now block — colors, fonts, borders, radius, width, spacing — with Native Checkout or Custom URL redirect.
 * Version:           1.0.0
 * Author:            NRW India
 * Author URI:        https://wp.nrwone.in
 * Text Domain:       essential-product-page-editor
 * Requires PHP:      7.4
 * Requires at least: 5.8
 * WC requires at least: 4.0
 *
 * @package Essential_Product_Page_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'EPE_VERSION', '1.0.0' );
define( 'EPE_PLUGIN_FILE', __FILE__ );
define( 'EPE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'EPE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'EPE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * -----------------------------------------------------------------------
 * GitHub based auto-update system.
 * Update source (as requested): https://github.com/sourabhdev41
 * NOTE: Point this at the *specific repository* that hosts this plugin's
 * releases, e.g. https://github.com/sourabhdev41/essential-product-page-editor
 * The updater looks at the repo's tags/releases to detect new versions -
 * bump the "Version:" header above and push a tag/release to publish an update.
 * -----------------------------------------------------------------------
 */
require_once EPE_PLUGIN_DIR . 'includes/puc/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$epe_update_checker = PucFactory::buildUpdateChecker(
	'https://github.com/sourabhdev41/essential-product-page-editor/',
	__FILE__,
	'essential-product-page-editor'
);

// Using the "main" branch as the update source by default.
$epe_update_checker->setBranch( 'main' );

// If you publish proper GitHub Releases with a zip asset attached,
// uncomment the next line so PUC downloads that asset instead of a
// branch snapshot (recommended for production use):
// $epe_update_checker->getVcsApi()->enableReleaseAssets();

/**
 * Core plugin class.
 */
final class Essential_Product_Page_Editor {

	/**
	 * Single instance.
	 *
	 * @var Essential_Product_Page_Editor
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Init plugin after all plugins are loaded so we can check dependencies.
	 */
	public function init() {

		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'notice_missing_elementor' ) );
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'notice_missing_wc' ) );
			return;
		}

		load_plugin_textdomain( 'essential-product-page-editor', false, dirname( EPE_PLUGIN_BASENAME ) . '/languages' );

		add_action( 'elementor/elements/categories_registered', array( $this, 'register_widget_category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );

		add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_frontend_assets' ) );

		// Buy Now handler - runs after WooCommerce's own add-to-cart handler (priority 20).
		add_action( 'wp_loaded', array( $this, 'handle_buy_now' ), 30 );
	}

	/**
	 * Register a dedicated Elementor widget category.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elements manager.
	 */
	public function register_widget_category( $elements_manager ) {
		$elements_manager->add_category(
			'epe-category',
			array(
				'title' => __( 'Essential Product Page Editor', 'essential-product-page-editor' ),
				'icon'  => 'eicon-woocommerce',
			)
		);
	}

	/**
	 * Register widget(s).
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager.
	 */
	public function register_widgets( $widgets_manager ) {
		require_once EPE_PLUGIN_DIR . 'includes/class-epe-cart-buy-widget.php';
		$widgets_manager->register( new \EPE_Cart_Buy_Widget() );
	}

	/**
	 * Enqueue front-end + editor assets.
	 */
	public function enqueue_frontend_assets() {
		wp_register_style( 'epe-style', EPE_PLUGIN_URL . 'assets/css/style.css', array(), EPE_VERSION );
		wp_enqueue_style( 'epe-style' );

		wp_register_script( 'epe-script', EPE_PLUGIN_URL . 'assets/js/script.js', array( 'jquery' ), EPE_VERSION, true );
		wp_enqueue_script( 'epe-script' );
	}

	/**
	 * Handle the "Buy Now" submission: add product to cart then redirect
	 * either to the native WooCommerce checkout or a custom URL.
	 */
	public function handle_buy_now() {

		if ( empty( $_REQUEST['epe_buy_now'] ) || ! isset( $_REQUEST['epe_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['epe_nonce'] ) ), 'epe_buy_now_action' ) ) {
			return;
		}

		$product_id = absint( wp_unslash( $_REQUEST['epe_buy_now'] ) );

		if ( ! $product_id ) {
			return;
		}

		$quantity = empty( $_REQUEST['quantity'] ) ? 1 : wc_stock_amount( wp_unslash( $_REQUEST['quantity'] ) );

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return;
		}

		$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );

		if ( ! $passed_validation ) {
			return;
		}

		$variation_id = 0;
		$variation    = array();

		$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );

		if ( ! $cart_item_key ) {
			return;
		}

		$redirect_type = ! empty( $_REQUEST['epe_redirect_type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['epe_redirect_type'] ) ) : 'checkout';

		if ( 'custom' === $redirect_type && ! empty( $_REQUEST['epe_redirect_url'] ) ) {
			$url = esc_url_raw( wp_unslash( $_REQUEST['epe_redirect_url'] ) );
		} else {
			$url = wc_get_checkout_url();
		}

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Missing Elementor notice.
	 */
	public function notice_missing_elementor() {
		echo '<div class="notice notice-warning is-dismissible"><p>' .
			esc_html__( 'Essential Product Page Editor requires Elementor (free or Pro) to be installed and activated.', 'essential-product-page-editor' ) .
			'</p></div>';
	}

	/**
	 * Missing WooCommerce notice.
	 */
	public function notice_missing_wc() {
		echo '<div class="notice notice-warning is-dismissible"><p>' .
			esc_html__( 'Essential Product Page Editor requires WooCommerce to be installed and activated.', 'essential-product-page-editor' ) .
			'</p></div>';
	}
}

Essential_Product_Page_Editor::instance();
